# Portfolio

<aside>
💡

NO ES VIABLE! Ha recortado los videos en webp!

</aside>

- curriculum - dandy - elegancia - built my life
    
    a thing that makes me happy/motivates me is creativity and developing "things" that others could enjoy and/or find useful.
    
    I would like to built my life around those ideas.
    
    And, if possible, I'd like to built my life
    I'd like my life to spin/orbits those ideas, since they simply makes me feel happy and content with myself.
    

- Details matters
    
    When I’m dessigning some thing, I like to be very conscious about every decision
    
    I do think that details matters, and they all have an impact. Even when the user don’t notices it consciously.
    
    Silly things as, for example:
    
    The stroke direction was choosen intentionally to emphatize contrast when the layer is selected (with the pencil icon). Both icon’s direction are opposite, making it more recognizable
    
    Even if that could appear a silly detail, and noti, it will reduce eye-fatigue
    
    This could make me, sometimes, slow when deciding things
    
    I do like (and tend) to be thoughful about the things I make, and I’m always willing to learn to improve, and I’m open to critizise.
    
- Perfectionist (DETAILS) 👀📏 (SZK Pixel Art Suite UI)
    
    (TEXTO PARA EL PORTFOLIO)
    
    (Sobre ser perfeccionista)
    Cons:
    
    - I'm very perfectionist: I knows this sounds kinda the same as telling someone in a date "Something bad about me? Well, I'm a very good person", but I'll explain why I think this is totally bad (at least for me):
        - It makes me slower for some task. Sometimes I find it hard to let go something if I still think that it could be done better. I do often imagine (lots of) possible scenerios where a change must be necessary, even if they won't happen.
        Lately I'm trying to solve it by simply asking myself "does it the job?" or "is it enough?". And thinking that "when you aim for perfection, you realize that it is a moving target". But I often find it hard. But I'm trying "to water" the "fuck it" part of me.
    
    ---
    
    Atencion al `detalle` insana
    
    (poner el ejemplo de las letras de la gameboy. No me vale con poner una fuente, quiero que se sienta real, que al verla te recuerde que una vez rascaste el logo sin querer y saltó un trozo de la pintura)
    
    I personally think UI is PRETTY important. When making an interface, it should be easy and intuitive to use, but I do also believe that a good UI can inspire the users. Specially when it is a tool.
    
    From the point of viewe of the user
    
- “My core values and life and work philosophy”
    - I think kindness is important

# Idea porfolio (para enviar a empresas (borrar este texto cuando lo apunte en aprendizajes))

“Solicitud - OPORTUNIDAD! Tal vez puedas ser tú el que me permita pagar el alquiler y no morir de hambre!”

“Hola, me llamo Óscar y estoy buscando trabajo.

**Este es mi portfolio, en caso de que consideréis que alguna de mis habilidades encajan y/u os puedan ser útiles!**

- Learning is my philosophy
    
    Both in a profesional and personal way.
    
    I think that having the mindset ready to learn it even relieves possible bad situations/downs in life. Just asking ourselves “what can I learn from that?” or “what can I do better next time?”
    

---

Index:

![=anim_webp_19-03-2023_20-14-00,20.webp](anim_webp_19-03-2023_20-14-0020.webp)

<aside>
💡 Hacer museo en 3d (a lo videojuego)?
+ Me motivaría a hacer algo en 3D
+ Sería algo muy original
+ Aprendería mucho
- Tiempo

—
”Welcome to ‘The shitty place where I place some things I made’”

</aside>

### About me & my work philosophy

First, I don’t like talking about me a single bit, but I’m going to try:

My name is Óscar and I consider myself more of an stubborn than a talented person, in no matter the topic.

I’m technically an engineer, but with a deep love for arts (drawing, music, painting, modeling, etc).

I tend to be highly critic with myself (also called commonly a perfectionist), and I think that absolutely everything “could be a bit better” if we work on it “just a bit more”.

![295899183_687654819452906_8545268497302774366_n_polaroid.png](295899183_687654819452906_8545268497302774366_n_polaroid.png)

![=anim_webp_19-03-2023_19-59-39,63.webp](anim_webp_19-03-2023_19-59-3963.webp)

![=anim_webp_19-03-2023_20-12-21,86.webp](anim_webp_19-03-2023_20-12-2186.webp)

Cons:

- Tend to have a low self esteem (but is at least high enough to admit it). `no pongas esto joder`

Pros:

- 

Learning is a thing where I find some meaning in this temporary -and maybe nonsense- thing called life. Is a thing that really fullfills me. I do agree with this quote said by some greek philosopher that I dont remember:

> Life is about sculpting our own sculpture.
> 

I personally think that the core root element for learning absolutely every topic that mankind has developed (like, science, philosophy, arts, psychology etc.), is observation. I do believe that being a good observer literally makes easier to learn and to transfer knowledge to different topics. I do really think that being a programer

Even being different topicsIs easy to abstract some core 

, and I like to approach different matters and problems with different perspectives. I think is useful when solving problems.

I do really think that the more we spread our skill-set, the wider our perspective and the richer our personal tool-bag will be.

I think this is a valuable tool when it comes to enginering/problem solving. The more we expand our knowledge, the wider our vision and the more easier for us will be to spot possible paths to overcome a particular problem.

Even thought, I sometimes also think that having some sort of “tunnel vision”, and focus on a single path, is also beneficial. But overall, knowing the possible different approaches, despite maybe it delays a bit the action (since there are more things to consider), is always beneficial and a good thing to be aware all the ramifications.

Learning to learn.

I’m curious by nature, and that made me dive into a lot of topics. And diving into lot of topics I think that caused me some anxiety and imposter syndrome. I use to think that “I’m not good enought, yet”. But I’m learning to deal with that feeling. I’m always doing my best.

For me is important to feel proud about the things I do. If I’m not proud, I’ll be the first one disapointed with whatever the thing I’m working on. I do think

and if we are compromised with ourselves and with our time… I personally think that is a very natural an reasonable “approach”.

Personality is one of the things I value the most

If something has no personality, is not special from the rest. If its not special, we are going to forget it. If we forget it it wasn’t important.

I love learning to learn. I love knowing different topics and extracting core lessons that could be applied to any field.

> When
> 

I do think and feel that when we have fun or enjoy the process while doing a craft (no matter the type), that joy and feelings ends being “encapsulated” in the final product/result. So we have to (honestly) believe in what we are doing (while don’t being blind, and be our hardest critic to improve it).

### Team

When it comes to working in a team,

When working with others in a team, I do adapt eassily. I do like to be as kind as I can with others when comunicating, just as I’d like others to be with me. Doing games must be something fun, that we all enjoy (at least, the 8X% of the time 🥸).

Technically, I’m a frustrated physician that later became a multimedia engineer.

I personally tend to think that if we ourselves don’t enjoy something, why we would expect others to do so?

I love making games since it encapsulates a lot of things that I truly love

My main strength is my main weakness; I like to do a lot of things.

When it comes to art,. I’m not interested in lying to myself.

There are lot of things that I still don’t understand, things I want

I hope reading all this text helped loading all the images and animations in the page 😶. 

And thanks you for making some time to read this and for taking a look to the portfolio.

---

I will add some insights about my philosophy while I’m working in different fields/aspects. I know it may be boring to read for some. But if you find it boring or don’t care about it, it would mean that you don’t care about your work, so I wouldn’t like to work/associate with you, so no need to further reading.

(Hope this doesn’t sound arrogant or anything, I just like to be honest. I don’t aim to be in a google-like workplace where we spend more time playing billiard/pool than working, but I ).

- 🧠 about Art

# 2D & Illustration

## Traditional ✒️

![portraits collage.png](portraits_collage.png)

![Class collage_shadow100_40-half.png](Class_collage_shadow100_40-half.png)

![animals slide.webp](animals_slide.webp)

![WhatsApp Image 2022-10-14 at 19.04.31_polaroid_shadow100_36-half.png](WhatsApp_Image_2022-10-14_at_19.04.31_polaroid_shadow100_36-half.png)

![Enderezado_polaroid_shadow100_30-half.png](Enderezado_polaroid_shadow100_30-half.png)

![collage urbano 2-half.png](collage_urbano_2-half.png)

![IMG_20200412_184717_1_RECORTADO-small_polaroid_shadow100_19-75percent.png](IMG_20200412_184717_1_RECORTADO-small_polaroid_shadow100_19-75percent.png)

![bus collage-half.png](bus_collage-half.png)

## Digital 💻

![NPH Barney Stinson 7_shadow100_15.png](NPH_Barney_Stinson_7_shadow100_15.png)

![El tonto del bote borde_shadow100_16.png](El_tonto_del_bote_borde_shadow100_16.png)

![WhatsApp Image 2022-10-14 at 19.04.29 (1)_borde_shadow100_10.png](WhatsApp_Image_2022-10-14_at_19.04.29_(1)_borde_shadow100_10.png)

![Chester Bennington Edit 2024 2.png](Chester_Bennington_Edit_2024_2.png)

![insi.webp](insi.webp)

![Portada v30 - FINAL MOD-half_shadow100_19.png](Portada_v30_-_FINAL_MOD-half_shadow100_19.png)

![Egg Express - Portada 3 - MOD-half_shadow100_13.png](Egg_Express_-_Portada_3_-_MOD-half_shadow100_13.png)

![Dexter made with *Poxol Odotor* (self made drawing app (which is not finished))](anim_webp_16-01-2023_14-07-2396.webp)

Dexter made with *Poxol Odotor* (self made drawing app (which is not finished))

![Hitchiker Wallpaper_shadow100_37-half.png](Hitchiker_Wallpaper_shadow100_37-half.png)

![I don’t know why I added this, but I liked the gif, to be honest. I think (this) is freaking awesome.](output_fa4.mov.webp)

I don’t know why I added this, but I liked the gif, to be honest. I think (this) is freaking awesome.

![Digital varios collage.png](Digital_varios_collage.png)

![output_ThePath - intro.mov.webp](output_ThePath_-_intro.mov.webp)

![Raros anim.webp](Raros_anim.webp)

![App icons/logos dessign (Anonimous Youtube Playlists, Deck Motif & Simple Texture Merger in that order)](Icons_compilation.png)

App icons/logos dessign (Anonimous Youtube Playlists, Deck Motif & Simple Texture Merger in that order)

## Pixel Art

![Kalavera Luna_recorte_shadow100_10.png](Kalavera_Luna_recorte_shadow100_10.png)

![Scar Tissue 2-export_shadow100_16.png](Scar_Tissue_2-export_shadow100_16.png)

![Road - Edits_shadow100_25.png](Road_-_Edits_shadow100_25.png)

![Color Dodge =TW Final - x4_shadow100_24.png](Color_Dodge_TW_Final_-_x4_shadow100_24.png)

![=montage_16-01-2023_22-50-58,97-small_shadow100_24.png](montage_16-01-2023_22-50-5897-small_shadow100_24.png)

### Portraits

![finish1-marco_interesante v3_shadow100_16.png](finish1-marco_interesante_v3_shadow100_16.png)

![edit-no_border-export_shadow100_12.png](edit-no_border-export_shadow100_12.png)

![losseles.webp](losseles.webp)

![=faces1 v1_shadow100_46.png](faces1_v1_shadow100_46.png)

### Games

B. Bullet

![tutorials suck.mp4_output.webp](tutorials_suck.mp4_output.webp)

![smoke particles.mp4_output.webp](smoke_particles.mp4_output.webp)

![SAQ-GifRecopilacion x4.gif](SAQ-GifRecopilacion_x4.gif)

![Lengua v2 x3.gif](Lengua_v2_x3.gif)

![rainy_day.webp](rainy_day.webp)

![ResultsGifTHANKYOU.gif](ResultsGifTHANKYOU.gif)

![2022-02-13_001309_shadow100_25.png](2022-02-13_001309_shadow100_25.png)

![cochecito.webp](cochecito.webp)

## Portraits

## Animation

# 3D

- Mouse Spaceship
    
    The main idea was to make a spaceship that reminded of a mouse/hamster.
    
    ![Quick concept art sketches about the main shape of the spaceship](concept_art.png)
    
    Quick concept art sketches about the main shape of the spaceship
    
    ![2022-02-13_011909-half_shadow100_14.png](2022-02-13_011909-half_shadow100_14.png)
    
    ![2022-02-13_012232-half_shadow100_14.png](2022-02-13_012232-half_shadow100_14.png)
    
    ![Texture 64x64 px](64x64.png)
    
    Texture 64x64 px
    

![=pixel_resolution_x3.webp](pixel_resolution_x3.webp)

- Cozy Cabin
    
    Texture made for an *Sketchfab* contest that was about making a hand painted texture for a cozy cabin.
    
    I tried to imitate a pencil-traditional-like art style, also inspired by Tim Burton.
    
    <aside>
    ℹ️ I only did painting the texture here (the lowpoly 3D model was already given to every participant of the contest).
    
    </aside>
    
    ![=anim_webp_23-01-2023_22-17-27,51.webp](anim_webp_23-01-2023_22-17-2751.webp)
    

![CozyCabin.png](CozyCabin.png)

- Voxel Treehouse
    
    ![DQPFohHW0AAzVm_MARCO_shadow100_19.png](DQPFohHW0AAzVm_MARCO_shadow100_19.png)
    

![cabaña.webp](cabaa.webp)

- Needle
    
    My goal was to make an asset that seemed like an ink illustration on a static frame.
    
    ![Screenshot - 09_02_2019 , 17_27_07 v2-MARCO_shadow100_13.png](Screenshot_-_09_02_2019__17_27_07_v2-MARCO_shadow100_13.png)
    

![output_Aguja - Clean 3.mov.webp](output_Aguja_-_Clean_3.mov.webp)

- Berto Romero caricature
    
    ![collage.png](collage.png)
    
    ![Berto el fary12_shadow100_16.png](Berto_el_fary12_shadow100_16.png)
    

![=anim_webp_23-01-2023_23-16-01,43.webp](anim_webp_23-01-2023_23-16-0143.webp)

- Ignatius Farray caricature
    
    ![wip.webp](wip.webp)
    

![=mariposa_textura_suave_FINAL_q90fps33.webp](mariposa_textura_suave_FINAL_q90fps33.webp)

### 2D illustrations to 3D

Transferring other’s people awesome 2D pieces/art styles into to 3D. I like it because its a kinda brainy challenging exercise trying to figure how to match things into 3D, and I also enjoy it.

*(Click ▶️ to open more content)*

- Music
    
    ![Original illustration by [@408seijin](https://twitter.com/408seijin) (left) and 3D recreation by me (right)](Original_(left)_and_3D_(right).png)
    
    Original illustration by [@408seijin](https://twitter.com/408seijin) (left) and 3D recreation by me (right)
    
    ![Making-of screenshots](seijin_collge_2.png)
    
    Making-of screenshots
    

![q88.webp](q88.webp)

- Ghost House
    
    ![Original illustration by Jon Klassen (left) and 3D recreation by me (right)](anim_webp_19-01-2023_0-34-2403.webp)
    
    Original illustration by Jon Klassen (left) and 3D recreation by me (right)
    

![output_nF1Qstz8qJ9wukxZ.mp4.webp](output_nF1Qstz8qJ9wukxZ.mp4.webp)

- Treehouse
    
    ![Original illustration by [@alijtemmens](https://www.instagram.com/alijtemmens/) (left) and 3D recreation by me (right)](Trehouse_Final_Comparisson_(fressnel_and_freestyle).png)
    
    Original illustration by [@alijtemmens](https://www.instagram.com/alijtemmens/) (left) and 3D recreation by me (right)
    

![Final (Fresnel and Shadow).webp](Final_(Fresnel_and_Shadow).webp)

- Grumpy-Smiley Monster
    
    ![Original illustration by [Toby Dixon](https://mobile.twitter.com/TbDxn) ([@TbDxn](https://mobile.twitter.com/TbDxn)) (left) and 3D recreation by me (right)](anim_webp_20-01-2023_18-12-4366.webp)
    
    Original illustration by [Toby Dixon](https://mobile.twitter.com/TbDxn) ([@TbDxn](https://mobile.twitter.com/TbDxn)) (left) and 3D recreation by me (right)
    
    ![outputQ90_chocobolo-tbdxn grumpy man.mp4.webp](outputQ90_chocobolo-tbdxn_grumpy_man.mp4.webp)
    
    ![=anim_webp_22-01-2023_17-58-44,43.webp](anim_webp_22-01-2023_17-58-4443.webp)
    

![output_2LWo4yN_XZ6r1O7e.mp4.webp](output_2LWo4yN_XZ6r1O7e.mp4.webp)

- Downwell
    
    ![Original Downwell in-game frame by Ojiro Fumoto ([@moppppin](https://twitter.com/moppppin)) (left) and 3D recreation by me (right)](Comparisson.png)
    
    Original Downwell in-game frame by Ojiro Fumoto ([@moppppin](https://twitter.com/moppppin)) (left) and 3D recreation by me (right)
    
    ![Render Downwell FULL_shadow100_71.png](Render_Downwell_FULL_shadow100_71.png)
    

![v5-q60.webp](v5-q60.webp)

![v6-rotfull.webp](v6-rotfull.webp)

- Marbles
    
    Marbles is a charming character designed by Trudi Castle ([@trudicastle](https://twitter.com/trudicastle), [@lady_tea](https://www.instagram.com/lady_tea/?hl=es)).
    
    ![Paper Preview v4_shadow100_22.png](Paper_Preview_v4_shadow100_22.png)
    
    ![=Wireframe to AO.webp](Wireframe_to_AO.webp)
    

![=FINAL V4 combinado mix 40percent.webp](FINAL_V4_combinado_mix_40percent.webp)

# Games

Forgotten Game - Personal game

# Apps

Animación Deck motif

Simple Texture Merger

- Programming Texto
    
    I do believe tiny details are very important (in so many aspects). I think they show we care (again, in so many aspects).
    
    So from making a simple animation/transition to feel better:
    
    (comparación lineal y ease (del addon de blender))
    
    to making/adding a silly dessign to make something pop-up or more “personal” or simply “curious”
    
    It has to do the job, but in my opinion, it has to make it in a cool way!
    
    And “in a cool way” can mean so many things:
    
    - To make something feel better `(gif preview layers, linear vs smooth en Blender Addon Groups)`
    - More understanable `(gif blender groups, ease option y como cambia de linear a smooth en Blender Addon Groups)`
        
        ![groups_preferences_ease.gif](groups_preferences_ease.gif)
        
    - To simply more personal `(icono calavera en Blender Addon Groups)`
    
    When it comes to coding, I like to be very tidy. Always refactoring.
    
    I do like to apply that kind of “scout motto”; “*leave things better than they were before*” in so many fields/aspects of my life. So when it comes to programming, I’m always with the mindset of “how can this thing be better?” (understanding “better” as “clearer” (easier to read) or more optimized, etc).
    
    (hacer lo del ease)
    
    I often enjoy making utilities/tools. I think is very fullfilling to do tools that others can use for their own advantage.
    

UI

# Music

I started composing and producing my own music in 2010.

When it comes to music, I tend to be eclectic, and not to be focused in just a few genres.

Music composition reel:

(Apart from original songs, I’ve also decided to include covers from different artists/bands to show how I can ~~ruin~~ adapt different styles and/or reintepret other’s songs in a different style).

[https://www.youtube.com/watch?v=Vw8hnal0lHQ](https://www.youtube.com/watch?v=Vw8hnal0lHQ)

---

Some personal interpretations from a well know tune; Tubular Bells by Mike Oldfield (The Exorcist main theme):

`(poner cacho guay)`