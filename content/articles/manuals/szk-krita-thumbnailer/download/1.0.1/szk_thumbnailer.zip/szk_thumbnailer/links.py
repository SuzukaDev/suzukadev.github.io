from PyQt5.QtWidgets import QPushButton, QWidget, QMainWindow
from webbrowser import open

from PyQt5.QtCore import QLocale

MANUAL_ENGLISH = "https://suzukadev.github.io/en/articles/manuals/szk-krita-thumbnailer/"
MANUAL_SPANISH = "https://suzukadev.github.io/es/articles/manuals/szk-krita-thumbnailer/"

# TODO CAMBIAR ESTO
GUMROAD_PAGE = "https://orb91.gumroad.com/l/szk-krita-thumbnailer"

def init(centralWidget:QWidget):
    gumroad_support_button:QPushButton = centralWidget.supportButton
    gumroad_support_button.pressed.connect(_on_gumroad_button_pressed)
    
    open_manual_button:QPushButton = centralWidget.openManualButton
    open_manual_button.pressed.connect(_open_online_manual)


def open_link(url:str):
    """Open a URL in the default web browser"""
    open(url)


def _on_gumroad_button_pressed(event=None):
    open_link(GUMROAD_PAGE)


def _open_online_manual():
    # Get the current system locale language used by Krita
    # current_language = QLocale.system().name()

    # print("Current language:", current_language)
    
    # print(QLocale().languageToString(QLocale().language()))
    # print(QLocale().countryToString(QLocale().country()))
    language = QLocale().languageToString(QLocale().language()).lower()
    # country = QLocale().countryToString(QLocale().country()).lower()
    if language == "spanish":
        open_link(MANUAL_SPANISH)
    else:
        open_link(MANUAL_ENGLISH)
