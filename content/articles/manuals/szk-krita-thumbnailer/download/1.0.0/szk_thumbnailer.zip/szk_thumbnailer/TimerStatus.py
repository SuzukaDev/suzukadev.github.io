
from enum import Enum

class TimerStatus(Enum):
    STOPPED = 1
    RUNNING = 2
    PAUSED = 3
