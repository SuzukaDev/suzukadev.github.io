# load autocomplete
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .PyKrita import *
else:
    from krita import *

SETTINGS_GROUP = "SZK_Thumbnailer"
# METHODS_TO_SAVE = ["isChecked", "value"]
# METHODS_TO_SAVE = ["value"]


# METHODS_TO_SAVE = {"value": {
#                         "setter": "setValue",
#                         "getter": "value"
#                         }
#                    }

METHODS_TO_SAVE = {"value": {
                            "setter": "setValue"
                            },
                   "isChecked": {
                            "setter": "setChecked"
                            }
                   }



class SaveData:
    def __init__(self, widget):
        self.main_widget:QWidget = widget
        self._connect_save_function()
        self.load_settings()
    
    
    def _connect_save_function(self):
        # Connect saving function
        self.notifier = Krita.instance().notifier()
        self.notifier.setActive(True)
        # self.notifier.applicationClosing.connect(self.save_data)  # DO NOT WORK! (IDKW!)
        # self.notifier.imageClosed.connect(lambda: save_data.save_data(self))
        self.notifier.imageClosed.connect(self.save_settings)
    
    
    def _get_all_children(self) -> list[QWidget]:
        # return self.main_widget.children()
        # return self.main_widget.findChild(QWidget)        
        return self.main_widget.findChildren(QSpinBox) + self.main_widget.findChildren(QCheckBox) + self.main_widget.findChildren(QDoubleSpinBox)
    
    def save_settings(self):
        settings = QSettings()
        # settings.beginGroup("MyDocker")
        settings.beginGroup(SETTINGS_GROUP)
        
        # DELETE
        # settings.setValue("newLayerCheckBox", self.main_widget.newLayerCheckBox.isChecked())
        
        
        
        # for widget in self.main_widget.children():
        # all_widgets_childrens = self.main_widget.findChild(QWidget)
        # for widget in all_widgets_childrens:
        for widget in self._get_all_children():
            # print(f"{widget.objectName() = }")
            # print(f"{hasattr(widget, 'isChecked') = }")
            
            value_to_save = None
            method_to_save = None
            
            # if hasattr(widget, 'isChecked'):
            
            # if any([hasattr(widget, _attribute) for _attribute in methods_to_save]):
                # value_to_save = getattr(widget, method_that_the_widget_has)
            
            for _method in METHODS_TO_SAVE.keys():
                if hasattr(widget, _method):
                    value_to_save = getattr(widget, _method)()
                    method_to_save = _method
            
            
            
            if value_to_save != None:
                settings.setValue(widget.objectName(), value_to_save)
                print(f"SAVED!")
                print(f"{widget.objectName() = }")
                print(f"{value_to_save = }")
        
        settings.endGroup()
        

    def load_settings(self):
        # return
        settings = QSettings()
        # settings.beginGroup("MyDocker")
        settings.beginGroup(SETTINGS_GROUP)
        
        
        # self.main_widget.newLayerCheckBox.setChecked(settings.value("newLayerCheckBox", False, type=bool))
        
        # for widget in self.main_widget.children():
        # all_widgets_childrens = self.main_widget.findChild(QWidget)
        # for widget in all_widgets_childrens:
        for widget in self._get_all_children():

            # value_to_save = None
            # method_to_save = None
            
            # if hasattr(widget, 'isChecked'):
            
            # if any([hasattr(widget, _attribute) for _attribute in methods_to_save]):
                # value_to_save = getattr(widget, method_that_the_widget_has)
            
            for _method in METHODS_TO_SAVE.keys():
                if hasattr(widget, _method):
                    # value_to_save = getattr(widget, _method)
                    # method_to_save = _method
                    # self.main_widget.newLayerCheckBox.setChecked(settings.value("newLayerCheckBox", False, type=bool))
                    # _saved_value = settings.value(widget.objectName(), type=METHODS_TO_SAVE[_method].get("type", str))
                    getter = getattr(widget, _method)
                    _saved_value = settings.value(widget.objectName(), type=type(getter()))
                    if _saved_value:
                        setter_name = METHODS_TO_SAVE[_method]["setter"]
                        # setattr(widget, _method, _saved_value)
                        setter = getattr(widget, setter_name)
                        setter(_saved_value)
                        # widget.set
                        
                    
            
            # if value_to_save != None:
            #     settings.setValue(widget.objectName(), value_to_save)
        
        settings.endGroup()