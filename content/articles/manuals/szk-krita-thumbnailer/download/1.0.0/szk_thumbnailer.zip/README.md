# SZK Thumbnailer

> ## Thumbnailer is a Krita docker plugin designed to streamline and accelerate thumbnail creation for coming up with new ideas.

It automatically divides the canvas into multiple thumbnail areas and cycles through selections manually or automatically (at user-defined intervals), allowing for rapid, uninterrupted sketching and ideation.
<figure><img src="https://public-files.gumroad.com/6czs86p3sfovictg4kn85wzp6slk"><p class="figcaption"><em>Thumbnailer keeps you painting, not fiddling.</em></p></figure>

It comes with an **action** for **randomly select a brush preset**. This useful to help you to “discover”/choose brushes you are not used to, or have forget about, and to achieve new results.

<figure><img src="https://public-files.gumroad.com/8cvnh0rsa05wrb0wg51zpzrv135f"><p class="figcaption"></p></figure>

Is use this for coming up with different brushes that creates contrast when making each thumbnail.


> This was inspired by the French Concept Artist & Illustrator **Stephane Richard (Wootha)**.

# Online Manual 📘

[Manual (English)](https://suzukadev.github.io/en/articles/manuals/szk-krita-thumbnailer/)

[Manual (Español)](https://suzukadev.github.io/es/articles/manuals/szk-krita-thumbnailer/)  

# Support 🍀

If you find it useful and want to support the project, any amount is welcome. You can also check other plugins I did, like [my -awesome- Pixel Art Suite for Krita](https://orb91.gumroad.com/l/szk-krita-pixel-art-suite).