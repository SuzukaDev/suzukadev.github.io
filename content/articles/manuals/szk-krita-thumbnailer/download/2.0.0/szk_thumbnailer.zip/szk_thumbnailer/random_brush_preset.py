# load autocomplete
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .PyKrita import *
else:
    from krita import *

import random


def set_random_brush_preset():
    allBrushPresets = Krita.instance().resources('preset')

    brushes_names_list = list(allBrushPresets.keys())
    random_brush_name = random.choice(brushes_names_list)

    currentView = Krita.instance().activeWindow().activeView()
    random_brush_preset = allBrushPresets[random_brush_name]
    
    currentView.setCurrentBrushPreset(random_brush_preset)
    
    # debug_print_methods(currentView)
    
    current_brush = currentView.currentBrushPreset()
    # debug_print_methods(current_brush)