from PyQt5.QtWidgets import *

# load autocomplete
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .PyKrita import *
else:
    from krita import *
            
from PyQt5 import uic
import os

import random

from .Thumbnailer import Thumbnailer
from .TimerStatus import TimerStatus
from .save_data import SaveData
from . import links
from .random_brush_preset import set_random_brush_preset

PROGRES_BAR_REFRESH_RATE = 100

DOCKER_TITLE = "SZK Thumbnailer"
PLUGIN_ID = "szk_thumbnailer"




class szk_thumbnailer(DockWidget):

    def __init__(self):
        super().__init__()
        self.setWindowTitle("SZK Thumbnailer")
        self.centralWidget = uic.loadUi( os.path.join(os.path.dirname(os.path.realpath(__file__)),"szk_thumbnailer.ui"))
        
        self.label:QLabel = self.centralWidget.label

        # layout = QVBoxLayout()
        # layout.addWidget(self.centralWidget)
        # self.setLayout(layout)
        
        self.start_button:QPushButton = self.centralWidget.startButton
        self.stop_button:QPushButton = self.centralWidget.stopButton
        self.previous_thumbnail_button:QPushButton = self.centralWidget.previousThumbnailButton
        self.next_thumbnail_button:QPushButton = self.centralWidget.nextThumbnailButton
        self.label_info:QLabel = self.centralWidget.infoLabel
        self.time_spinbox:QSpinBox = self.centralWidget.timeSpinBox
        self.divisions_spinbox:QSpinBox = self.centralWidget.divisionsSpinBox
        self.progress_bar:QProgressBar = self.centralWidget.progressBar
        self.random_brush_button:QPushButton = self.centralWidget.randomBrushButton
        self.randomize_brush_checkbox:QCheckBox = self.centralWidget.randomizeBrushCheckBox
        self.randomize_brush_twice_checkbox:QCheckBox = self.centralWidget.randomizeBrushTwiceCheckBox
        
        self.randomize_brush_checkbox.toggled.connect(self.on_randomize_brush_checkbox_toggled)
        self._init_randomize_brush_button()
        
        self.timer_progress_bar = QTimer()
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)
        
        
        # self.time_spinbox.valueChanged.connect(self.on_data_changed)
        # self.divisions_spinbox.valueChanged.connect(self.on_data_changed)
        
        self.app = Krita.instance()
        
        self.thumbnailer:Thumbnailer = Thumbnailer(self)
        
        self.thumbnailer.thumbnailer_stopped.connect(self.on_stop_button_pressed)
        self.thumbnailer.thumbnailer_started.connect(self.on_thumbnail_timer_started)
        
        self.previous_thumbnail_button.pressed.connect(self.thumbnailer.select_previous_thumbnail)
        self.next_thumbnail_button.pressed.connect(self.thumbnailer.select_next_thumbnail)
        self.start_button.pressed.connect(self.thumbnailer.start_button_pressed)
        self.stop_button.pressed.connect(self.thumbnailer.stop_button_pressed)
        
        self.start_button.pressed.connect(self.on_start_button_pressed)
        self.stop_button.pressed.connect(self.on_stop_button_pressed)
        
        self.random_brush_button.pressed.connect(set_random_brush_preset)
        self.random_brush_button.setIcon(Krita.instance().icon("krita_tool_lazybrush"))
        
        
        # self.thumbnailer.timer_paused_signal.connect(self.on_timer_paused)
        
        self.setWidget(self.centralWidget)  # Use setWidget instead of setting a layout
        
        
        self.tab_widget:QTabWidget = self.centralWidget.tabWidget
        self.tab_widget.setTabIcon(0, Krita.instance().icon("animation_play"))
        self.tab_widget.setTabIcon(1, Krita.instance().icon("properties"))
        self.tab_widget.setTabIcon(2, Krita.instance().icon("selection-info"))
        
        self.previous_thumbnail_button.setIcon(Krita.instance().icon("arrow-left"))
        self.next_thumbnail_button.setIcon(Krita.instance().icon("arrow-right"))
        self.start_button.setIcon(Krita.instance().icon("animation_play"))
        self.stop_button.setIcon(Krita.instance().icon("animation_stop"))
        self.start_button.setText("")
        self.stop_button.setText("")
        
        links.init(self.centralWidget)
        
        # self.on_data_changed()
        
        self.save_data = SaveData(self.centralWidget)
        
        
        # app = Krita.instance()
    
    def on_start_button_pressed(self):
        if self.thumbnailer.state == TimerStatus.PAUSED:
            self.start_button.setIcon(Krita.instance().icon("animation_play"))
        else:
            self.start_button.setIcon(Krita.instance().icon("animation_pause"))
    
    # DELETE y borrar referencias
    # def on_data_changed(self, new_value=0):
    #     self._update_label_info()
    
    
    def on_randomize_brush_checkbox_toggled(self, toggled):
        self.randomize_brush_twice_checkbox.setEnabled(toggled)
    
    
    def _init_randomize_brush_button(self):
        self.randomize_brush_twice_checkbox.setEnabled(self.randomize_brush_checkbox.isChecked())
    
    
    # DELETE
    # def _update_label_info(self):
    #     # total_time = (self.thumbnailer.total_thumbnails * self.thumbnailer.thumbnail_time)/60.0
    #     # total_seconds = (self.divisions_spinbox.value()**2 * self.time_spinbox.value())
    #     total_thumbnails = len(self.thumbnailer.thumbnails)
    #     total_seconds = (total_thumbnails * self.time_spinbox.value())
    #     # self.label_info.setText(f"{self.thumbnailer.total_thumbnails} thumbnails ({total_time/60} mins)")
    #     mins = total_seconds/60
    #     # self.label_info.setText(f"{self.thumbnailer.total_thumbnails} thumbnails ({'{:.1f}'.format(mins)} mins)")
    #     self.label_info.setText(f"{total_thumbnails} thumbnails ({'{:.1f}'.format(mins)} mins)")
    #     # self.label_info.setText(f"{self.thumbnailer.total_thumbnails} thumbnails ({total_seconds}s)")
    
    
    def on_stop_button_pressed(self):
        self.start_button.setIcon(Krita.instance().icon("animation_play"))
        try:
            self.timer_progress_bar.timeout.disconnect(self._on_progress_bar_timeout)
        except TypeError:
            # Already disconnected or was never connected
            pass
        self.progress_bar.setVisible(False)
        print(f"on_stop_button_pressed")
    
    
    def on_thumbnail_timer_started(self):
        if self.centralWidget.showBarCheckBox.isChecked():
            self.timer_progress_bar.timeout.connect(self._on_progress_bar_timeout)
            self.timer_progress_bar.start(PROGRES_BAR_REFRESH_RATE)
            self.progress_bar.setValue(0)
            self.progress_bar.setVisible(True)
    
    
    def _on_progress_bar_timeout(self):
        thumbnail_time = self.time_spinbox.value() * 1000
        remaining_time = self.thumbnailer.timer.remainingTime()
        if remaining_time < 0:
            remaining_time = self.thumbnailer.remaining_time_on_paused
        percent = ((thumbnail_time - remaining_time) / thumbnail_time)*100
        self.progress_bar.setValue(int(percent))
        # print(f"_on_progress_bar_timeout   {percent}")
    
    
    # def on_timer_paused(self):
        # self.start_button.setIcon(Krita.instance().icon("animation_pause"))

    
    def canvasChanged(self, canvas):
        pass
    
    
    

def retrieveThumbnailerDocker()->szk_thumbnailer:
    for d in Krita.instance().activeWindow().dockers():
        if d.objectName() == PLUGIN_ID:
            if isinstance(d, szk_thumbnailer):
                return d
    return None





class SZKThumbnailerActions(Extension):
    def __init__(self, parent):
        super().__init__(parent)
        self.docker:szk_thumbnailer = None
        # self.docker:szk_thumbnailer = retrieveThumbnailerDocker()


    def setup(self):
        pass


    def previous_thumbnail(self):
        self.docker:szk_thumbnailer = retrieveThumbnailerDocker()
        self.docker.thumbnailer.select_previous_thumbnail()
        
        
    def next_thumbnail(self):
        self.docker:szk_thumbnailer = retrieveThumbnailerDocker()
        self.docker.thumbnailer.select_next_thumbnail()



        
    
    # called after setup(self)
    # Override
    # INFO https://docs.krita.org/en/user_manual/python_scripting/krita_python_plugin_howto.html#creating-an-extension
    def createActions(self, window:Window):
        shortcuts_name_suffix = f" ({DOCKER_TITLE})"
        
        # Open menu
        action:QAction = window.createAction(PLUGIN_ID, DOCKER_TITLE, "Tools/Scripts")
        self.menu = QMenu(PLUGIN_ID, window.qwindow())
        action.setMenu(self.menu)
        
        # TODO action tooltips/Descriptions! do not work!
        # action.setToolTip("setToolTip")
        # action.setWhatsThis("setWhatsThis")
        # action.triggered.connect(self.previous_palette_color)
        # Krita.instance().actionCollection().addAction("my_action_id", action)
        
        # Next & Previous Thumbnails
        previous_thumbnail_action = window.createAction("selectPreviousThumbnail", "Select Previous Thumbnail"+shortcuts_name_suffix, f"Tools/Scripts/{PLUGIN_ID}")
        previous_thumbnail_action.triggered.connect(self.previous_thumbnail) 
        
        next_thumbnail_action = window.createAction("selectNextThumbnail", "Select Next Thumbnail"+shortcuts_name_suffix, f"Tools/Scripts/{PLUGIN_ID}")
        next_thumbnail_action.triggered.connect(self.next_thumbnail) 
        
        # Random Brush
        random_brush_action = window.createAction("selectRandomBrush", "Select Random Brush"+shortcuts_name_suffix, f"Tools/Scripts/{PLUGIN_ID}")
        random_brush_action.triggered.connect(set_random_brush_preset)



Krita.instance().addDockWidgetFactory(DockWidgetFactory("szk_thumbnailer", DockWidgetFactoryBase.DockRight, szk_thumbnailer)) 
Krita.instance().addExtension(SZKThumbnailerActions(Krita.instance()))









#  region THUMBNAILS SELECTION ⸻⸻⸻⸻⸻⸻⸻⸻⸻⊸






