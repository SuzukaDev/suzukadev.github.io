from __future__ import annotations

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .PyKrita import *
else:
    from krita import *

from PyQt5.QtCore import pyqtSignal

from .Thumbnail import Thumbnail


UNIFORM_GRID = "Uniform Grid"
CUSTOM_GRID= "Custom Grid"
RANDOM_GRID= "Random Grid"
LAYOUTS_ALGORITHMS = [UNIFORM_GRID, CUSTOM_GRID, RANDOM_GRID]


class ThumbnailsGenerator(QObject):
    layout_property_changed:pyqtSignal = pyqtSignal()
    
    def __init__(self, main_widget)->None:
        super().__init__()
        self.main_docker = main_widget
        self.layout_combobox:QComboBox = main_widget.layoutComboBox
        self.divisions_spinbox:QSpinBox = main_widget.divisionsSpinBox
        self.divisionsX_spinbox:QSpinBox = main_widget.divisionsXSpinBox
        self.divisionsY_spinbox:QSpinBox = main_widget.divisionsYSpinBox
        self.randomness_slider:QSlider = main_widget.randomnessSlider
        self.randomness_grid_slider:QSlider = main_widget.randomnessGridSlider
        self.total_thumbnails_spinBox:QSpinBox = main_widget.totalThumbnailsSpinBox
        self.layout_settings_groupbox:QGroupBox = main_widget.layoutSettingsGroupBox
        
        self.randomness:float = self._get_randomness_percentage()
        
        self._init_layout_combobox()
        
        self._connect_layout_change_signals()

        self.layout_combobox.currentIndexChanged.connect(self._on_current_layout_index_changed)
        self._manage_widgets_visibility()

    
    def _on_current_layout_index_changed(self):
        self._manage_widgets_visibility()
    
    
    def _manage_widgets_visibility(self):
        active_text = self.layout_combobox.currentText()
        self.main_docker.subdivisionsGroupBox.setVisible(active_text == UNIFORM_GRID)
        self.main_docker.xySubdivisionsGroupBox.setVisible(active_text == CUSTOM_GRID)
        self.main_docker.totalThumbnailsGroupBox.setVisible(active_text == RANDOM_GRID)
        # self.main_docker.randomnessGroupBox.setVisible(active_text in LAYOUTS_ALGORITHMS)
        # Random groupbox
        self.main_docker.randomnessGridGroupBox.setVisible(active_text in [UNIFORM_GRID, CUSTOM_GRID])
        self.main_docker.randomnessRandomGroupBox.setVisible(active_text == RANDOM_GRID)
    
    
    def _connect_layout_change_signals(self):
        for c in self.layout_settings_groupbox.children():
            if hasattr(c, "valueChanged"):
                c.valueChanged.connect(self.on_layout_property_changed)
            if c.children():
                for gc in c.children():
                    if hasattr(gc, "valueChanged"):
                        gc.valueChanged.connect(self.on_layout_property_changed)
        self.layout_combobox.currentIndexChanged.connect(self.on_layout_property_changed)
    
    
    def on_layout_property_changed(self):
        self.layout_property_changed.emit()
    
    
    def _get_document_aspect_ratio(self)->float:
        doc:Document = Krita.instance().activeDocument()
        return doc.width()/doc.height()
    
    
    def _init_layout_combobox(self):
        for algorithm in LAYOUTS_ALGORITHMS:
            self.layout_combobox.addItem(algorithm)
    
    
    def _get_randomness_percentage(self):
        self.randomness:float = self.randomness_slider.value() / self.randomness_slider.maximum()
        return self.randomness
    
    
    def _get_randomness_grid_percentage(self):
        return self.randomness_grid_slider.value() / self.randomness_grid_slider.maximum()
    
    
    def generate_thumbnails_layout(self) -> list[Thumbnail]:
        app = Krita.instance()
        if app.activeDocument() is None:
            return []
        document_thumbnail = Thumbnail(document=app.activeDocument())
        if self.layout_combobox.currentText() == UNIFORM_GRID:
            divisions = self.divisions_spinbox.value() # - 1
            return [document_thumbnail] + document_thumbnail.split(divisions, divisions, self._get_randomness_grid_percentage())
        elif self.layout_combobox.currentText() == CUSTOM_GRID:
            x_divisions = self.divisionsX_spinbox.value() # - 1
            y_divisions = self.divisionsY_spinbox.value() # - 1
            return [document_thumbnail] + document_thumbnail.split(x_divisions, y_divisions, self._get_randomness_grid_percentage())
        elif self.layout_combobox.currentText() == RANDOM_GRID:
            total_thumbnails = self.total_thumbnails_spinBox.value()
            return self._get_random_thumbnails_layout(total_thumbnails, document_thumbnail)
    
    
    def get_biggest_thumbnail(self, thumbnails:list[Thumbnail])->Thumbnail:
        """Gets the thumbnail with the bigger area from a list of Thumbnails

        Args:
            thumbnails (list[Thumbnail]): Array with the list of thumbnails

        Returns:
            Thumbnail: The biggest thumbnail
        """
        # biggest_thumbnail = max(thumbnails, key=lambda x: x.area())
        # areas = [a.area() for a in thumbnails]
        # print(f"{areas = }")
        # print(f"{biggest_thumbnail.area() = }")
        return max(thumbnails, key=lambda x: x.area())
    
    
    def get_thumbnail_with_more_different_aspect_ratio(self, thumbnails:list[Thumbnail])->Thumbnail:
        doc_ascpect_ratio = self._get_document_aspect_ratio()
        most_different_aspect_ratio_thumbnail = max(thumbnails, key=lambda x: x.aspect_ratio_difference_score(doc_ascpect_ratio))
        # return max(thumbnails, key=lambda x: x.area())
        return most_different_aspect_ratio_thumbnail
    
    
    def get_biggest_thumbnail_with_more_different_aspect_ratio(self, thumbnails:list[Thumbnail])->Thumbnail:
        doc_aspect_ratio = self._get_document_aspect_ratio()
        biggest_and_most_different_thumbnail = max(thumbnails, key=lambda x: x.aspect_ratio_difference_score(doc_aspect_ratio) * x.area()*10)
        return biggest_and_most_different_thumbnail
    
    
    def _get_random_thumbnails_layout(self, total_thumbnails:int, document_thumbnail:Thumbnail)->list[Thumbnail]:
        thumbnails:list[Thumbnail] = [document_thumbnail]
        thumbnails_len = len(thumbnails)
        while thumbnails_len < total_thumbnails:
            # thumbnail_to_split = self.get_biggest_thumbnail(thumbnails)
            # thumbnail_to_split = self.get_thumbnail_with_more_different_aspect_ratio(thumbnails)
            thumbnail_to_split = self.get_biggest_thumbnail_with_more_different_aspect_ratio(thumbnails)
            # split_result = thumbnail_to_split.random_split(self._get_randomness_percentage())
            split_result = thumbnail_to_split.split_to_keep_doc_aspect_ratio(self._get_randomness_percentage())
            
            # Append the new thumbnails next to the thumbnail that was splited
            index = thumbnails.index(thumbnail_to_split)
            thumbnails[index:index] = split_result
            
            thumbnails_len = len(thumbnails)
        thumbnails.reverse()
        return thumbnails