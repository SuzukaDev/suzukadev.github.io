from __future__ import annotations

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    # from .PyKrita import *
    # from .zchachi
    # from .zchachi.PyKrita import *
    # from .KRITA_API import *
    from .PyKrita import *
else:
    from krita import *
    

# from krita import Krita
import random
from PyQt5.QtGui import QImage, QPainter, QColor, QRegion
from PyQt5.QtCore import QRect, QTimer, pyqtSignal

from .TimerStatus import TimerStatus
from .random_brush_preset import set_random_brush_preset

# ROWS = 3
# COLS = 3
DIVISIONS = 2

# TODO cambiar esto
RANDOM = .1


# class Thumbnailer(QObject):
class Thumbnail:
    # timer_paused_signal:pyqtSignal = pyqtSignal()
    # thumbnailer_started:pyqtSignal = pyqtSignal()
    # thumbnailer_stopped:pyqtSignal = pyqtSignal()
    
    # random_level:float = .0
    
    
    # def __init__(self, main_docker, x:int, y:int, width:int, height:int)->None:
    def __init__(self, x:int=0, y:int=0, width:int=100, height:int=100, document:Document=None)->None:
        super().__init__()
        # self.main_docker = main_docker
        # self.main_widget = main_docker.centralWidget
        # print(f"{document = }")
        if document:
            self.x:int = 0
            self.y:int = 0
            self.width:int = document.width()
            self.height:int = document.height()
        else:
            self.x:int = int(x)
            self.y:int = int(y)
            self.width:int = int(width)
            self.height:int = int(height)
    
    
    def area(self) -> int:
        return self.width * self.height
    
    
    def relative_area(self) -> float:
        """Returns a float between 0.0 and 1.0 with the proportion of the area of the thumbnail by the document's area.

        Returns:
            float: 0.0 to 1.0
        """
        active_doc:Document = Krita.instance().activeDocument()
        document_area = active_doc.width() * active_doc.height()
        return self.area() / document_area
    
    
    def aspect_ratio(self) -> float:
        return self.width / self.height
    
    
    def aspect_ratio_difference_score(self, other_aspect_ratio = None)->float:
        """Determines how different is the thumbnail's aspect ratio to another aspect ratio.
        
        Args:
            other_aspect_ratio (float): if None, it will take the active document's aspect ratio

        Returns:
            float: Difference score. The higher the value, the more different the aspect ratios are
        """
        if other_aspect_ratio is None:
            doc = Krita.instance().activeDocument()
            other_aspect_ratio = doc.width()/doc.height()
        return abs(self.aspect_ratio() - other_aspect_ratio)
    

    def select_thumbnail(self, padding:int=0)->None:
        # TODO
        app = Krita.instance()
        # invert_selection = app.action('invert_selection')
        doc = app.activeDocument()

        sel:Selection = Selection()
        # sel.select(self.x, self.y, self.width, self.height, 255)
        
        # sel.shrink(padding, padding, False)
        relative_padding = round(padding/1000 * min(doc.height(), doc.width()))
        # relative_padding = int(padding/1000 * (doc.height() * doc.width()))
        
        # sel.select(self.x+relative_padding, self.y+relative_padding, self.width - relative_padding, self.height - relative_padding, 255)
        
        
        relative_padding = round(relative_padding / 2)
        # print(f"{relative_padding = }")
        sel.select(self.x+relative_padding, self.y+relative_padding, self.width - relative_padding*2, self.height - relative_padding*2, 255)
        # sel.select(self.x+relative_padding, self.y+relative_padding, self.width - relative_padding, self.height - relative_padding, 255)
        # sel.select(self.x+1, self.y+1, self.width - 1, self.height - 1, 255)
        # sel.select(self.x+1, self.y+1, self.width , self.height , 255)
        
        
        # sel.shrink(relative_padding, relative_padding, False)
        
        doc.setSelection(sel)
        # doc.refreshProjection() 
        
        # invert_selection.trigger()
        # invert_selection.trigger()
    
    # REFACTOR
    def split(self, x_times:int = 2, y_times:int = 0, randomness:float = 0.0) -> list[Thumbnail]:
        
        def split_segment(total_size, total_splits:int, random_level=0.0)->list[float]:
            # total_splits += 1
            uniform_size = total_size / total_splits
            # print(f"{total_splits = }")
            # print(f"{total_size = }")
            # rand_level = RANDOM
            # segments = [ uniform_size + random.uniform(-rand_level, rand_level)*uniform_size for _ in range(total_splits)]
            segments = [ uniform_size + random.uniform(-random_level, random_level)*uniform_size for _ in range(total_splits)]
            # print(f"{segments = }")
            # print(f"{sum(segments) = }")
            scale = total_size/sum(segments)
            # print(f"{sum(segments) = }")
            segments = [scale * _segment for _segment in segments]
            return segments
        
        split_thumbnails:list[Thumbnail] = []
        # if self.x
        
        original_width:int = self.width
        original_height:int = self.height
        # start_x = self.x
        # start_y = self.y
        # new_equal_width = self.width/x_times
        # previous_thumbnail = self
        
        # widths:list[int] = []
        # for i in range(x_times):
        #     # FIXME esto tendría que cambiarlo y hacerlo aleatorio tal vez
        #     da_width = new_equal_width
        #     previous_thumbnail.width = new_equal_width
        #     new_thumbnail = Thumbnail(previous_thumbnail.x + new_equal_width, previous_thumbnail.y, da_width)
            
        #     previous_thumbnail = new_thumbnail
        
        
        # widths:list[int] = [i*new_equal_width + random.randrange(0, RANDOM)*new_equal_width for i in range(x_times)]
        
        # widths:list[int] = [i*300 + random.randrange(0, 0)*300 for i in range(3)]
        # import random
        # widths:list = [i*300 + random.randrange(0.0, 1.0)*300 for i in range(3)]
        # widths:list = [i*300 + ((random.random()*2)-1.0)*RANDOM*300 for i in range(3)]
        # widths:list = [i*new_equal_width + ((random.random()*2)-1.0)*RANDOM*new_equal_width for i in range(x_times)]
        
        if x_times > 0:
            widths = split_segment(original_width, x_times, randomness)
        else:
            widths = [original_width]
        
        if y_times > 0:
            heights = split_segment(original_height, y_times, randomness)
        else:
            heights = [original_height]
        # print(f"{random.randrange(0, 100)/100 = }")
        # print(f"{random.random() = }")
        
        # print(f"{widths = }")
        # print(f"{heights = }")
        
        current_y = self.y
        for h in heights:
            current_x = self.x
            for w in widths:
                new_thumbnail = Thumbnail(x=current_x, y=current_y, width=w, height=h)
                split_thumbnails.append(new_thumbnail)
                current_x += w
                # new_thumbnail.print()
            current_y += h
            
        
        
        # prev = self
        # for w in widths:
        #     print(f"{w = }")
        #     new_thumbnail = Thumbnail(prev.x+prev.width, prev.y, w, prev.height)
        #     prev = new_thumbnail
        #     split_thumbnails.append(new_thumbnail)
        first_thumbnail = split_thumbnails.pop(0)
        self.width = first_thumbnail.width
        self.height = first_thumbnail.height
        
        return split_thumbnails
    
    
    def random_split(self, randomness):
        if random.random() < .5:
            return self.split(2, 0, randomness)
        else:
            return self.split(0, 2, randomness)
    
    # REFACTOR
    def split_to_keep_doc_aspect_ratio(self, randomness):
        doc = Krita.instance().activeDocument()
        doc_aspect_ratio = doc.width()/doc.height()
        # self.aspect_ratio is is more horizontal than the original -> Split in X
        if self.aspect_ratio() > doc_aspect_ratio:
            # return self.split(0, 2, randomness)
            return self.split(2, 0, randomness)
        # self.aspect_ratio is is more vertical than the original -> Split in Y
        else:
            # return self.split(2, 0, randomness)
            return self.split(0, 2, randomness)
            
    
    
    def print(self):
        print(f"Thumbnail: {self.x = } {self.y = } {self.width = } {self.height = }")
    
    

# def test_print(array:list[Thumbnail]):
#     for element in array:
#         element.print()
    

# test = Thumbnail(0,0, 1000, 1000)
# grid = test.split(x_times=1)
# test_print(grid)

