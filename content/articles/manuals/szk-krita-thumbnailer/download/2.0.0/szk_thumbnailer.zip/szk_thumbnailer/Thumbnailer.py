from typing import TYPE_CHECKING
if TYPE_CHECKING:
    # from .PyKrita import *
    # from .zchachi
    # from .zchachi.PyKrita import *
    # from .KRITA_API import *
    from .PyKrita import *
else:
    from krita import *

# from krita import Krita
from PyQt5.QtGui import QImage, QPainter, QColor, QRegion
from PyQt5.QtCore import QRect, QTimer, pyqtSignal
import random

from .TimerStatus import TimerStatus
from .random_brush_preset import set_random_brush_preset
from .Thumbnail import Thumbnail
from .ThumbnailsGenerator import ThumbnailsGenerator

# ROWS = 3
# COLS = 3
DIVISIONS = 2

app = Krita.instance()

if not hasattr(app, '_timer'):
    app._timer = QTimer()
# timer:QTimer = QTimer()


def get_thumbnail_size(doc_w:int, doc_h:int)->tuple[int, int]:
    # return int(doc_w/COLS), int(doc_h/ROWS)
    return int(doc_w/DIVISIONS), int(doc_h/DIVISIONS)
    

def make_random_selection():
    app = Krita.instance()
    doc = app.activeDocument()
    if doc is None:
        print("No active document.")
        return

    width = doc.width()
    height = doc.height()
    
    
    invert_selection = app.action('invert_selection')

    # # Create a transparent QImage the size of the document
    # selection_mask = QImage(width, height, QImage.Format_ARGB32)
    # selection_mask.fill(QColor(0, 0, 0, 0))  # fully transparent

    # painter = QPainter(selection_mask)
    # painter.setBrush(QColor(255, 255, 255, 255))  # white (fully selected)
    # painter.setPen(QColor(255, 255, 255, 255))

    # # Create 10 random rectangles to add to the selection
    # for _ in range(10):
    #     rw = random.randint(30, width // 4)
    #     rh = random.randint(30, height // 4)
    #     rx = random.randint(0, width - rw)
    #     ry = random.randint(0, height - rh)
    #     painter.drawRect(rx, ry, rw, rh)

    # painter.end()

    # # Apply the selection mask to the document
    # doc.setSelection(selection_mask)
    # doc.refreshProjection() 
    
    print(f"{width = }")
    sel:Selection = Selection()
    # sel.x = 10
    # sel.y = 10
    # sel.width = 20
    # sel.height = 20
    
    rw = random.randint(30, width // 4)
    rh = random.randint(30, height // 4)
    rx = random.randint(0, width - rw)
    ry = random.randint(0, height - rh)
    
    Krita.instance().action('deselect').trigger()
    # sel.select(10, 10, 400, 100, 100) #255 is totally selected
    sel.select(rx, ry, rw, rh, 255) #255 is totally selected
    
    # sel.select(0, 0, *get_thumbnail_size(width, height), 255) #255 is totally selected
    
    i = 0
    # divisions=2
    total_cells = DIVISIONS**2
    x = i%DIVISIONS
    # y = int(i/total_cells)
    y = i//DIVISIONS
    tw, th = get_thumbnail_size(width, height)
    # sel.select(x*tw, y*th, tw,th, 255) #255 is totally selected
    
    
    
    print(f"selection width: {sel.width()}")
    print(f"selection height: {sel.height()}")
    # sel.contract(20)
    # sel.grow(10, 20)
    # sel.move(10,30)
    sel.shrink(2,2, False)
    doc.setSelection(sel)
    doc.refreshProjection() 
    
    print(f"new selection width: {sel.width()}")
    print(f"new selection height: {sel.height()}")

    invert_selection.trigger()
    invert_selection.trigger()
    
    # print(dir(sel))
    # help(sel)

# make_random_selection()
# # QTimer.singleShot(4200, make_random_selection)
# # timer.setInterval(2000)
# # print(f"{timer = }")
# if hasattr(app, "_timer"):
#     print(f"{app._timer = }")
# else:
#     print(f"no lo tiene")
# # timer.timeout.connect(make_random_selection)  # Connect timeout to the function
# # timer.start(5000)  # Interval in milliseconds (5000ms = 5s)
# # timer.stop()


class Thumbnailer(QObject):
    timer_paused_signal:pyqtSignal = pyqtSignal()
    thumbnailer_started:pyqtSignal = pyqtSignal()
    thumbnailer_stopped:pyqtSignal = pyqtSignal()
    thumbnails_generated:pyqtSignal = pyqtSignal()
    
    def __init__(self, main_docker)->None:
        super().__init__()
        self.main_docker = main_docker
        self.main_widget = main_docker.centralWidget
        self.is_running = False
        self.is_paused = False
        self.thumbnails_generator = ThumbnailsGenerator(self.main_widget)
        self.thumbnails_generator.layout_property_changed.connect(self.on_layout_property_changed)
        self.main_docker.time_spinbox.valueChanged.connect(self._update_label_info)
        
        
        self.thumbnails:list[Thumbnail] = None
        self.state = TimerStatus.STOPPED
        self._init_values()
        self.thumbnails_generated.connect(self._update_label_info)


    def _init_values(self):
        if hasattr(self, "timer"):
            self.timer.stop()
        # self.thumbnails:list[Thumbnail] = self.generate_thumbnails()
        self.thumbnails:list[Thumbnail] = self.thumbnails_generator.generate_thumbnails_layout()
        self.total_thumbnails = len(self.thumbnails)
        self.main_docker.app.thumbnail_timer:QTimer = QTimer()
        self.timer:QTimer = self.main_docker.app.thumbnail_timer
        
        self.active_document:Document = Krita.instance().activeDocument()
        
        self._init_widgets_values()
        self.current_index = -1

        self.remaining_time_on_paused = 0


    def _init_widgets_values(self):
        self.add_layer_for_each_thumbnail = self.main_widget.newLayerCheckBox.isChecked()
        self.divisions = self.main_widget.divisionsSpinBox.value()
        self.padding = self.main_widget.paddingSpinBox.value()
        self.thumbnail_time = int(self.main_widget.timeSpinBox.value() * 1000)
        # self.total_thumbnails = self.divisions**2
        

    def _start_timer(self):
        self._init_values()
        # self.timer.timeout.connect(self.select_active_thumbnail)
        self.timer.timeout.connect(self.on_thumbnail_timeout)
        self.timer.setSingleShot(False)
        self.timer.start(self.thumbnail_time)
        self.is_running = True
        self.thumbnailer_started.emit()
    
    
    def _update_label_info(self):
        total_thumbnails = len(self.thumbnails)
        # total_seconds = (total_thumbnails * self.time_spinbox.value())
        total_seconds = (total_thumbnails * self.main_docker.time_spinbox.value())
        mins = total_seconds/60
        # self.label_info.setText(f"{total_thumbnails} thumbnails ({'{:.1f}'.format(mins)} mins)")
        self.main_docker.label_info.setText(f"{total_thumbnails} thumbnails ({'{:.1f}'.format(mins)} mins)")


    def start_button_pressed(self):
        if self.state == TimerStatus.STOPPED:
            self._start_timer()
            print(f"TIMER COMIENZAAAAAA")
            # self.select_active_thumbnail()
            self.on_thumbnail_timeout()
            # self.timer.start(5*1000)
            self.state = TimerStatus.RUNNING
        elif self.state == TimerStatus.RUNNING:
            self.remaining_time_on_paused = self.timer.remainingTime()
            self.timer.stop()
            self.state = TimerStatus.PAUSED
            self.timer_paused_signal.emit()
            # TODO emit signal paused
        elif self.state == TimerStatus.PAUSED:
            self.timer.start(self.remaining_time_on_paused)
            self.state = TimerStatus.RUNNING
        print(f"{self.timer.remainingTime() = }")
    
    def stop_button_pressed(self):
        self._stop_timer()
        
        
    def _stop_timer(self):
        self.timer.stop()
        self.current_index = 0
        # Krita.instance().action('deselect').trigger()
        # self.timer.timeout.disconnect(self.select_active_thumbnail)
        # print(f"TIMER PARADO")
        self.state = TimerStatus.STOPPED
        self.thumbnailer_stopped.emit()
    
    
    def get_thumbnail_size(self, doc_w:int, doc_h:int)->tuple[int, int]:
        return int(doc_w/self.divisions), int(doc_h/self.divisions)
    
    
    # NOTE esto era antes
    def PREVIOUS_make_thumbnail_selection(self, index:int = -1):
        # print(f"select_active_thumbnail")
        app = Krita.instance()
        doc = app.activeDocument()
        if doc is None:
            print("No active document.")
            return

        width = doc.width()
        height = doc.height()
        
        invert_selection = app.action('invert_selection')

        sel:Selection = Selection()
        # sel.x = 10
        # sel.y = 10
        # sel.width = 20
        # sel.height = 20
        
        rw = random.randint(30, width // 4)
        rh = random.randint(30, height // 4)
        rx = random.randint(0, width - rw)
        ry = random.randint(0, height - rh)
        
        # Krita.instance().action('deselect').trigger()
        
        # sel.select(10, 10, 400, 100, 100) #255 is totally selected
        # sel.select(rx, ry, rw, rh, 255) #255 is totally selected
        
        # sel.select(0, 0, *get_thumbnail_size(width, height), 255) #255 is totally selected
        
        if index < 0:
            i = self.current_index
        else:
            i = index
        # divisions=2
        total_cells = self.divisions**2
        x = i%self.divisions
        # y = int(i/total_cells)
        y = i//self.divisions
        tw, th = self.get_thumbnail_size(width, height)
        sel.select(x*tw, y*th, tw,th, 255) #255 is totally selected
        
        
        
        # print(f"selection width: {sel.width()}")
        # print(f"selection height: {sel.height()}")
        # sel.contract(20)
        # sel.grow(10, 20)
        # sel.move(10,30)
        sel.shrink(self.padding, self.padding, False)
        doc.setSelection(sel)
        doc.refreshProjection() 
        
        # print(f"new selection width: {sel.width()}")
        # print(f"new selection height: {sel.height()}")
        
        # print(f"{sel.x() = }")
        # print(f"{sel.y() = }")

        invert_selection.trigger()
        invert_selection.trigger()
    
    
    def get_current_thumbnail(self)->Thumbnail:
        if not self.thumbnails:
            self.thumbnails = self.thumbnails_generator.generate_thumbnails_layout()
        current_thumbnail = self.thumbnails[self.current_index]
        return current_thumbnail
    
        
    def select_active_thumbnail(self, index:int = -1):
        # current_thumbnail = self.thumbnails[self.current_index]
        # current_thumbnail.select_thumbnail(self.padding)
        self.get_current_thumbnail().select_thumbnail(self.padding)
        
        
    def _randomize_brush(self)->bool:
        # return self.main_widget.randomizeBrushCheckBox.isChecked()
        return self.main_docker.randomize_brush_checkbox.isChecked()
    
    def _randomize_brush_twice(self)->bool:
        return self.main_docker.randomize_brush_twice_checkbox.isChecked()


    def on_layout_property_changed(self):
        self._generate_thumbnails()
        self.thumbnails_generated.emit()
    
    
    def _generate_thumbnails(self):
        self.thumbnails = self.thumbnails_generator.generate_thumbnails_layout()
    
    
    def on_thumbnail_timeout(self):
        # if self.current_index > self.total_thumbnails-1:
        if self.current_index >= self.total_thumbnails-1:
            self._stop_timer()
            return
        
        # Randomize Brush
        if self._randomize_brush():
            set_random_brush_preset()
            if self._randomize_brush_twice():
                set_random_brush_preset()
                
        
        if self.add_layer_for_each_thumbnail:
            # Krita.instance().action('add_new_paint_layer').trigger()
            # self.active_document.refreshProjection()
            # Krita.instance().activeDocument().activeNode().setName(f"Thumbnail {self.current_index}")
            self.add_layer()
        
        self.current_index += 1
        self.select_active_thumbnail()
        
        if self.timer.interval() < self.thumbnail_time:
            self.timer.setInterval(self.thumbnail_time)
        
        # print(f"{self.total_thumbnails = }")
        # print(f"{self.current_index = }")

# def start_thumbnailer():

    def add_layer(self):
        # self.active_document.
        # new_layer = self.active_document.createNode()
        # above_node = self.active_document.activeNode().parentNode()
        parent_group = self.active_document.activeNode().parentNode()
        above_node = self.active_document.activeNode()
        root = self.active_document.rootNode()
        new_layer = self.active_document.createNode(f"Thumbnail {self.current_index+1}", "paintLayer")
        root.addChildNode(new_layer, above_node)
        # root.addChildNode(new_layer)
        if parent_group:
            parent_group.addChildNode(new_layer, None)
        self.active_document.setActiveNode(new_layer)
        self.active_document.refreshProjection()
    
    
    def select_previous_thumbnail(self):
        # print(f"ANTES: {self.current_index = }")
        # cur_index = self.current_index - 1
        # cur_index = max(0, cur_index)
        # self._init_widgets_values()
        # # self.current_index = cur_index
        # print(f"DESPUES: {self.current_index = }")
        # self.select_active_thumbnail(cur_index)
        
        self._init_widgets_values()
        self.current_index -= 1
        self.current_index = max(0, self.current_index)
        self.select_active_thumbnail()
    
    
    def select_next_thumbnail(self):
        # print(f"ANTES: {self.current_index = }")
        # cur_index = self.current_index + 1
        # cur_index = min(self.total_thumbnails-1, cur_index)
        # self._init_widgets_values()
        # # self.current_index = cur_index
        # print(f"DESPUES: {self.current_index = }")
        # self.select_active_thumbnail(cur_index)
        
        self._init_widgets_values()
        self.current_index += 1
        self.current_index = min(self.total_thumbnails-1, self.current_index)
        self.select_active_thumbnail()
    
    
    # TODO método generate_thumbnails
    """
    Según el método seleccionado genera los thumbnails
    # IDEA podría delegarlo a una clase llamada "thumbnail generator"
    """    

#  endregion (THUMBNAILS SELECTION) ______________________________________________



