# load autocomplete
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .PyKrita import *
else:
    from krita import *

import json
from os import path
from PyQt5 import uic

PRESETS_FILE = "presets.json"
SAVE_DIALOG_UI = "save_preset_dialog.ui"


class PresetsManager:
    def __init__(self, widget, save_data):
        self.main_widget:QWidget = widget
        self.save_data = save_data
        # self._connect_save_function()
        # self.load_settings()
        self._init_ui()
        self._load_presets_json()
        # self.json_file = path.join(path.dirname(path.realpath(__file__)), PRESETS_FILE)
    
    
    def _init_ui(self):
        self.presets_combobox:QComboBox = self.main_widget.presetsComboBox
        self.save_preset_button:QPushButton = self.main_widget.savePresetPushButton
        self.delete_preset_button:QPushButton = self.main_widget.deletePresetPushButton

        self.save_preset_button.setText("")
        self.delete_preset_button.setText("")
        self.save_preset_button.setIcon(Krita.instance().icon('document-save-16'))
        self.delete_preset_button.setIcon(Krita.instance().icon('edit-delete'))
        
        self.save_preset_button.pressed.connect(self.on_save_preset_pressed)
        self.delete_preset_button.pressed.connect(self.on_delete_preset_pressed)
        
        self.presets_combobox.currentIndexChanged.connect(self.on_preset_changed)
    
    
    def _load_presets_json(self):
        # Opening JSON file
        json_file = path.join(path.dirname(path.realpath(__file__)), PRESETS_FILE)
        f = open(json_file)
        # f = open(PRESETS_FILE)

        # returns JSON object as a dictionary
        self.presets = json.load(f)
        
        self._fill_combobox_presets()
        
        f.close()
        
    
    def _fill_combobox_presets(self):
        if not self.presets:
            return
        
        self.presets_combobox.clear()
        for preset_name in self.presets:
            self.presets_combobox.addItem(preset_name, self.presets[preset_name])
    
    
    def _init_presets_combobox(self):
        pass
    
    
    def on_save_preset_pressed(self):
        # print(f"save")
        # self.save_preset_dialog = uic.loadUi(path.join(path.dirname(path.realpath(__file__)), SAVE_DIALOG_UI))
        # self.save_preset_dialog.show()
        # result = self.save_preset_dialog.exec() # .exec makes it modal and blocks the input until the user press ok or cancel
        
        save_preset_dialog = uic.loadUi(path.join(path.dirname(path.realpath(__file__)), SAVE_DIALOG_UI)) # since is executed with exec, there is no need to save it on self.
        # save_preset_dialog = SavePresetDialog()
        # preset_line_edit = save_preset_dialog.findChild(QLineEdit, 'presetNameLineEdit')
        current_preset = self.presets_combobox.currentText()
        if current_preset:
            save_preset_dialog.presetNameLineEdit.setText(current_preset)
            save_preset_dialog.presetNameLineEdit.selectAll()
        # for w in save_preset_dialog.children():
        #     print(f"{w.objectName() = }")
        
        result = save_preset_dialog.exec() # .exec makes it modal and blocks the input until the user press ok or cancel
        
        if result == QDialog.Accepted:
            # preset_name = self.main_widget.presetNameLineEdit.text()
            preset_name = save_preset_dialog.presetNameLineEdit.text()
            # preset_line_edit = save_preset_dialog.findChild(QLineEdit, 'presetNameLineEdit')
            # preset_name = preset_line_edit.text()
            
            if preset_name in self.presets.keys():
                confirmation_box = QMessageBox()
                ret = confirmation_box.question(self.main_widget,'Overwrite presset', f"Overwrite '{self.presets_combobox.currentText()}' preset?", confirmation_box.Yes | confirmation_box.No)

                if ret == confirmation_box.No:
                    return
            
            self._save_active_preset(preset_name)
            self.presets_combobox.setCurrentText(preset_name)
        # else:
            # print("User canceled")
    
    
    def on_preset_changed(self, index:int):
        settings = self.presets_combobox.currentData()
        if settings:
            self.save_data.load_preset(settings)
    
    
    def _save_active_preset(self, preset_name:str):
        current_settings:dict = self.save_data.get_active_settings()
        # TODO checkear que no existe la key ya en los presets (el nombre)
        self.presets[preset_name] = current_settings
        self._fill_combobox_presets()
        
        self.save_presets_to_json()


    def save_presets_to_json(self):
        json_file = path.join(path.dirname(path.realpath(__file__)), PRESETS_FILE)
        # with open('data.json', 'w') as f:
        with open(json_file, 'w') as f:
            json.dump(self.presets, f)
    
    
    def on_delete_preset_pressed(self):
        confirmation_box = QMessageBox()
        ret = confirmation_box.question(self.main_widget,'Delete preset', f"Delete '{self.presets_combobox.currentText()}' preset?", confirmation_box.Yes | confirmation_box.No)

        if ret == confirmation_box.Yes:
            self._delete_active_preset()
    
    
    def _delete_active_preset(self):
        active_preset = self.presets_combobox.currentText()
        del self.presets[active_preset]
        self.save_presets_to_json()
        self._fill_combobox_presets()
    
    