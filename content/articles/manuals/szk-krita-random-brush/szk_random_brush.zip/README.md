# SZK Random Brush

A [Krita](https://krita.org/) plugin that adds an action for selecting a random brush.

This was inspired a thumbnail lesson by [Stephane (Wootha) Richard](https://www.artstation.com/learning/instructors/stephane-wootha-richard) and I personally use it for trying different brushes while **making thumbnails**.

![thumbnails made with the plugin](szk_random_brush/images/thumbnails.png)

I originally made this for my brother :)

## Usage

`Tools/Scripts/SZK random brush`. 

You can add a shortcut in preferences.

# Contact

Twitter: [@SuzukaKDev](https://twitter.com/SuzukaKDev)

Mail: suzukakadev@gmail.com
