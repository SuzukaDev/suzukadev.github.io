
# load autocomplete
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .PyKrita import *
else:
    from krita import *
            

from krita import *
import random


# TODO lista de tareas
# [] hacer que pueda seleccionar un pincel aleatorio solo del current tag
    # INFO Clase preset https://api.kde.org/krita/html/classPreset.html
# [] hacer que con un botón pueda pintar aleatoriamente algo en el documento 
    # [] Esto lo puedo encadenar en que ejecute X trazos para que cree un thumbnail
# ? Averiguar como obtengo información de un preset
# [] Random blending mode?


def debug_print_methods(element_to_print, print_in_column:bool = True):
    if print_in_column:
        print(f"Methods:")
        for method in dir(element_to_print):
            print(f"    {method}")
    else:
        print(f"{dir(element_to_print) = }")
        

class SZKRandomBrushExtension(Extension):

    def __init__(self, parent):
        super().__init__(parent)


    # Krita.instance() exists, so do any setup work
    def setup(self):
        pass


    def system_check(self):
        # QMessageBox creates quick popup with information
        messageBox = QMessageBox()
        messageBox.setInformativeText(Application.version())
        messageBox.setWindowTitle('System Check')
        messageBox.setText("Hello! Here is the version of Krita you are using.");
        messageBox.setStandardButtons(QMessageBox.Close)
        messageBox.setIcon(QMessageBox.Information)
        messageBox.exec()

    
    def set_random_brush_preset(self):
        allBrushPresets = Krita.instance().resources('preset')

        brushes_names_list = list(allBrushPresets.keys())
        random_brush_name = random.choice(brushes_names_list)

        currentView = Krita.instance().activeWindow().activeView()
        random_brush_preset = allBrushPresets[random_brush_name]
        
        currentView.setCurrentBrushPreset(random_brush_preset)
        
        # debug_print_methods(currentView)
        
        current_brush = currentView.currentBrushPreset()
        # debug_print_methods(current_brush)
        
    
    
    # INFO https://docs.krita.org/en/user_manual/python_scripting/krita_python_plugin_howto.html#creating-an-extension
    # called after setup(self)
    def createActions(self, window):
        # action = window.createAction("szk_random_brush", "SZK Random Brush", "tools/scripts/Patrick/Random")
        action = window.createAction("szk_random_brush", "SZK Random Brush", "tools/scripts/")
        # action.setShortcut("Ctrl+Q")
        action.triggered.connect(self.set_random_brush_preset)
        # action2.triggered.connect(self.system_check)
        
        


# And add the extension to Krita's list of extensions:
Krita.instance().addExtension(SZKRandomBrushExtension(Krita.instance())) 
